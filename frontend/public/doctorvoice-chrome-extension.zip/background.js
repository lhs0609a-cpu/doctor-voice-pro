// 백그라운드 서비스 워커 v13.4 - DOM 직접 조작 방식
console.log('[닥터보이스] 백그라운드 v13.4 시작 - DOM 직접 조작');

// 전역 변수
let pendingPostData = null;
let currentDebuggerTabId = null;

// 외부 메시지 수신 (웹페이지에서)
chrome.runtime.onMessageExternal.addListener(async (message, sender, sendResponse) => {
  console.log('[닥터보이스] 외부 메시지:', message.action);

  if (message.action === 'PING') {
    sendResponse({ success: true, version: '13.4.0' });
    return true;
  }

  if (message.action === 'PUBLISH_TO_BLOG') {
    console.log('[닥터보이스] 발행 요청:', message.data?.title);

    pendingPostData = message.data;
    await chrome.storage.local.set({
      pendingPost: message.data,
      autoPostEnabled: true
    });

    // 이미 열린 블로그 글쓰기 탭이 있는지 확인
    const tabs = await chrome.tabs.query({});
    const existingTab = tabs.find(tab =>
      tab.url && tab.url.includes('blog.naver.com') &&
      (tab.url.includes('Write') || tab.url.includes('editor'))
    );

    if (existingTab) {
      // 기존 탭 활성화 및 새로고침
      await chrome.tabs.update(existingTab.id, { active: true });
      await chrome.tabs.reload(existingTab.id);
      console.log('[닥터보이스] 기존 블로그 탭 사용:', existingTab.id);
    } else {
      // 새 탭 열기
      chrome.tabs.create({
        url: 'https://blog.naver.com/GoBlogWrite.naver',
        active: true
      });
    }

    sendResponse({ success: true });
    return true;
  }
});

// 내부 메시지 수신 (content script에서)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[닥터보이스] 내부 메시지:', message.action);

  if (message.action === 'GET_POST_DATA') {
    chrome.storage.local.get(['pendingPost', 'autoPostEnabled'], (result) => {
      sendResponse({
        success: true,
        data: result.pendingPost,
        autoPostEnabled: result.autoPostEnabled
      });
    });
    return true;
  }

  if (message.action === 'CLEAR_POST_DATA') {
    pendingPostData = null;
    chrome.storage.local.set({ pendingPost: null, autoPostEnabled: false });
    sendResponse({ success: true });
    return true;
  }

  // 완전자동 입력 요청
  if (message.action === 'AUTO_TYPE') {
    const tabId = sender.tab.id;
    console.log('[닥터보이스] AUTO_TYPE 요청, tabId:', tabId);
    console.log('[닥터보이스] 제목:', message.title?.substring(0, 30));
    console.log('[닥터보이스] 본문 길이:', message.content?.length);

    autoTypeWithDebugger(tabId, message.title, message.content, message.titlePos, message.bodyPos)
      .then((result) => {
        console.log('[닥터보이스] AUTO_TYPE 완료:', result);
        sendResponse({ success: true, result });
      })
      .catch((err) => {
        console.error('[닥터보이스] AUTO_TYPE 실패:', err);
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }
});

// 완전자동 입력 (Runtime.evaluate + DOM 직접 조작)
async function autoTypeWithDebugger(tabId, title, content, titlePos, bodyPos) {
  console.log('[닥터보이스] === 완전자동 입력 시작 (DOM 직접 조작) ===');

  try {
    // 1. debugger 연결
    console.log('[닥터보이스] 1단계: debugger 연결');
    await attachDebugger(tabId);

    // 2. 제목 입력: DOM으로 직접 focus + execCommand
    console.log('[닥터보이스] 2단계: 제목 입력');
    await insertTextViaDOM(tabId, 'title', title);
    await sleep(500);

    // 3. 본문 입력: DOM으로 직접 focus + execCommand
    console.log('[닥터보이스] 3단계: 본문 입력');
    await insertTextViaDOM(tabId, 'body', content);
    await sleep(200);

    // 4. debugger 연결 해제
    console.log('[닥터보이스] 4단계: debugger 해제');
    await detachDebugger(tabId);

    console.log('[닥터보이스] === 완전자동 입력 완료! ===');
    return { success: true };

  } catch (error) {
    console.error('[닥터보이스] 오류:', error);
    try { await detachDebugger(tabId); } catch (e) {}
    throw error;
  }
}

// DOM 직접 조작으로 텍스트 입력
async function insertTextViaDOM(tabId, type, text) {
  const selector = type === 'title'
    ? '.se-documentTitle .se-text-paragraph'
    : '.se-component.se-text:not(.se-documentTitle) .se-text-paragraph';

  const result = await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', {
    expression: `
      (function() {
        // iframe 내부 찾기
        let doc = document;
        const iframes = document.querySelectorAll('iframe');
        for (const iframe of iframes) {
          try {
            if (iframe.contentDocument && iframe.contentDocument.querySelector('.se-component')) {
              doc = iframe.contentDocument;
              break;
            }
          } catch(e) {}
        }

        // 요소 찾기
        const selector = '${selector}';
        const el = doc.querySelector(selector);
        if (!el) {
          return { success: false, error: 'Element not found: ' + selector };
        }

        // 포커스 및 선택
        el.focus();

        // 기존 내용 선택 및 삭제
        const selection = doc.getSelection();
        const range = doc.createRange();
        range.selectNodeContents(el);
        selection.removeAllRanges();
        selection.addRange(range);

        // execCommand로 텍스트 삽입
        const success = doc.execCommand('insertText', false, ${JSON.stringify(text)});

        if (!success) {
          // execCommand 실패 시 직접 입력
          el.textContent = ${JSON.stringify(text)};

          // React 이벤트 트리거
          const inputEvent = new InputEvent('input', {
            bubbles: true,
            cancelable: true,
            inputType: 'insertText',
            data: ${JSON.stringify(text)}
          });
          el.dispatchEvent(inputEvent);
        }

        // 포커스 해제를 위해 다른 곳 클릭
        const changeEvent = new Event('change', { bubbles: true });
        el.dispatchEvent(changeEvent);

        const blurEvent = new Event('blur', { bubbles: true });
        el.dispatchEvent(blurEvent);

        return { success: true, method: success ? 'execCommand' : 'textContent' };
      })()
    `,
    returnByValue: true
  });

  console.log('[닥터보이스] DOM 입력 결과:', result.result?.value);

  if (!result.result?.value?.success) {
    throw new Error(result.result?.value?.error || 'DOM 입력 실패');
  }
}

// 텍스트 입력 (클립보드 + Ctrl+V 방식 - 가장 안정적)
async function insertText(tabId, text) {
  console.log('[닥터보이스] 텍스트 삽입 시작, 길이:', text.length);

  try {
    // 1. Runtime.evaluate로 클립보드에 텍스트 복사 (페이지 컨텍스트에서 실행)
    await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', {
      expression: `
        (async () => {
          try {
            await navigator.clipboard.writeText(${JSON.stringify(text)});
            return true;
          } catch (e) {
            // 클립보드 API 실패 시 execCommand 사용
            const textarea = document.createElement('textarea');
            textarea.value = ${JSON.stringify(text)};
            textarea.style.position = 'fixed';
            textarea.style.left = '-9999px';
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            return true;
          }
        })()
      `,
      awaitPromise: true
    });
    console.log('[닥터보이스] 클립보드 복사 완료');

    await sleep(100);

    // 2. Ctrl+V로 붙여넣기
    await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
      type: 'keyDown',
      key: 'Control',
      code: 'ControlLeft',
      windowsVirtualKeyCode: 17,
      modifiers: 2
    });

    await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
      type: 'keyDown',
      key: 'v',
      code: 'KeyV',
      text: 'v',
      windowsVirtualKeyCode: 86,
      modifiers: 2
    });

    await sleep(100);

    await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
      type: 'keyUp',
      key: 'v',
      code: 'KeyV',
      windowsVirtualKeyCode: 86,
      modifiers: 2
    });

    await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
      type: 'keyUp',
      key: 'Control',
      code: 'ControlLeft',
      windowsVirtualKeyCode: 17,
      modifiers: 0
    });

    console.log('[닥터보이스] Ctrl+V 붙여넣기 완료');

  } catch (e) {
    console.error('[닥터보이스] 클립보드 방식 실패:', e.message);

    // 폴백: Input.insertText 시도
    try {
      await chrome.debugger.sendCommand({ tabId }, 'Input.insertText', {
        text: text
      });
      console.log('[닥터보이스] insertText 폴백 완료');
    } catch (e2) {
      console.error('[닥터보이스] insertText도 실패:', e2.message);
      throw e2;
    }
  }
}

// 클릭
async function clickAt(tabId, x, y) {
  console.log('[닥터보이스] 클릭:', x, y);

  await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
    type: 'mousePressed',
    x: x,
    y: y,
    button: 'left',
    clickCount: 1
  });

  await sleep(50);

  await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
    type: 'mouseReleased',
    x: x,
    y: y,
    button: 'left',
    clickCount: 1
  });

  console.log('[닥터보이스] 클릭 완료');
}

// 텍스트 입력
async function typeText(tabId, text) {
  console.log('[닥터보이스] 타이핑 시작, 길이:', text.length);

  const startTime = Date.now();

  for (let i = 0; i < text.length; i++) {
    const char = text[i];

    if (char === '\n') {
      // Enter 키
      await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
        type: 'keyDown',
        key: 'Enter',
        code: 'Enter',
        windowsVirtualKeyCode: 13,
        nativeVirtualKeyCode: 13
      });
      await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
        type: 'keyUp',
        key: 'Enter',
        code: 'Enter',
        windowsVirtualKeyCode: 13,
        nativeVirtualKeyCode: 13
      });
    } else {
      // 일반 문자 - char 이벤트로 직접 입력
      await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
        type: 'char',
        text: char
      });
    }

    // 진행상황 로그 (10% 단위)
    if (text.length > 100 && i > 0 && i % Math.floor(text.length / 10) === 0) {
      const progress = Math.round((i / text.length) * 100);
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log(`[닥터보이스] 타이핑 진행: ${progress}% (${elapsed}초)`);
    }

    // 속도 조절 (50자마다 약간 대기)
    if (i > 0 && i % 50 === 0) {
      await sleep(10);
    }
  }

  const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
  console.log(`[닥터보이스] 타이핑 완료! (${totalTime}초)`);
}

// debugger 연결
async function attachDebugger(tabId) {
  // 이미 연결되어 있으면 먼저 해제
  if (currentDebuggerTabId) {
    try {
      await detachDebugger(currentDebuggerTabId);
    } catch (e) {}
  }

  return new Promise((resolve, reject) => {
    chrome.debugger.attach({ tabId }, '1.3', () => {
      if (chrome.runtime.lastError) {
        console.error('[닥터보이스] debugger 연결 실패:', chrome.runtime.lastError.message);
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        currentDebuggerTabId = tabId;
        console.log('[닥터보이스] debugger 연결됨, tabId:', tabId);
        resolve();
      }
    });
  });
}

// debugger 연결 해제
async function detachDebugger(tabId) {
  return new Promise((resolve) => {
    chrome.debugger.detach({ tabId }, () => {
      if (chrome.runtime.lastError) {
        console.log('[닥터보이스] debugger 해제 경고:', chrome.runtime.lastError.message);
      }
      currentDebuggerTabId = null;
      console.log('[닥터보이스] debugger 연결 해제됨');
      resolve();
    });
  });
}

// sleep
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// debugger 연결 해제 감지
chrome.debugger.onDetach.addListener((source, reason) => {
  console.log('[닥터보이스] debugger 연결 해제됨:', reason);
  currentDebuggerTabId = null;
});

// 탭 업데이트 감지
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;

  const url = tab.url || '';
  if (!url.includes('blog.naver.com')) return;
  if (!url.includes('Write') && !url.includes('editor')) return;

  console.log('[닥터보이스] 블로그 글쓰기 페이지 감지, tabId:', tabId);

  const stored = await chrome.storage.local.get(['pendingPost', 'autoPostEnabled']);

  if (stored.autoPostEnabled && stored.pendingPost) {
    console.log('[닥터보이스] 자동 발행 데이터 있음!');

    setTimeout(async () => {
      try {
        await chrome.tabs.sendMessage(tabId, {
          action: 'INSERT_POST',
          data: stored.pendingPost
        });
        console.log('[닥터보이스] INSERT_POST 메시지 전송 완료');
      } catch (e) {
        console.log('[닥터보이스] 메시지 전송 실패:', e.message);
        // 재시도
        setTimeout(async () => {
          try {
            await chrome.tabs.sendMessage(tabId, {
              action: 'INSERT_POST',
              data: stored.pendingPost
            });
          } catch (e2) {
            console.log('[닥터보이스] 재시도 실패:', e2.message);
          }
        }, 2000);
      }
    }, 3000);
  }
});

// 서비스 워커 유지
chrome.alarms.create('keepAlive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(() => {});
