// ============================================================
// 닥터보이스 프로 - 네이버 블로그 자동 포스팅 엔진 v15
// SmartEditor ONE (blog.naver.com) 인페이지 컨트롤러
// 실제 확보한 안정 셀렉터(data-click-area / data-name / data-testid) 기반
// ============================================================
(() => {
  'use strict';
  const TAG = '[닥터보이스]';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // 이 프레임이 실제 에디터가 있는 프레임인지 판별
  const isEditorFrame = () =>
    !!document.querySelector('.se-component.se-documentTitle, .se-documentTitle');

  // ---------- 유틸: 요소 대기 ----------
  async function waitFor(selector, { timeout = 20000, root = document } = {}) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const el = root.querySelector(selector);
      if (el) return el;
      await sleep(150);
    }
    return null;
  }

  // ---------- 유틸: iframe 오프셋을 더한 뷰포트 절대 좌표 ----------
  function absoluteRect(el) {
    const r = el.getBoundingClientRect();
    let offX = 0;
    let offY = 0;
    try {
      // content script는 mainFrame(iframe) 내부에서 실행됨.
      // 같은 오리진(blog.naver.com)이라 frameElement 접근 가능.
      if (window.frameElement) {
        const fr = window.frameElement.getBoundingClientRect();
        offX = fr.left;
        offY = fr.top;
      }
    } catch (e) { /* cross-origin fallback: 오프셋 0 */ }
    return {
      x: Math.round(offX + r.left + r.width / 2),
      y: Math.round(offY + r.top + Math.min(r.height / 2, 24)),
      left: offX + r.left,
      top: offY + r.top,
      width: r.width,
      height: r.height,
    };
  }

  // ---------- 진행 오버레이 ----------
  let overlayEl = null;
  function showOverlay(text, pct) {
    if (!isTopDoc()) return; // 오버레이는 최상위 문서에만
    if (!overlayEl) {
      overlayEl = document.createElement('div');
      overlayEl.id = 'dv-poster-overlay';
      overlayEl.innerHTML = `
        <div class="dv-ov-card">
          <div class="dv-ov-spinner"></div>
          <div class="dv-ov-text">준비 중...</div>
          <div class="dv-ov-bar"><i></i></div>
          <div class="dv-ov-ver">닥터보이스 프로 v15.0</div>
        </div>`;
      const s = document.createElement('style');
      s.textContent = `
        #dv-poster-overlay{position:fixed;inset:0;z-index:2147483646;display:flex;
          align-items:center;justify-content:center;background:rgba(15,23,42,.55);
          font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}
        #dv-poster-overlay .dv-ov-card{background:#fff;border-radius:16px;padding:28px 34px;
          min-width:300px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.3)}
        #dv-poster-overlay .dv-ov-spinner{width:40px;height:40px;margin:0 auto 16px;
          border:4px solid #d1fae5;border-top-color:#10b981;border-radius:50%;
          animation:dvspin .8s linear infinite}
        @keyframes dvspin{to{transform:rotate(360deg)}}
        #dv-poster-overlay .dv-ov-text{font-size:15px;font-weight:600;color:#111827;margin-bottom:14px}
        #dv-poster-overlay .dv-ov-bar{height:6px;background:#e5e7eb;border-radius:3px;overflow:hidden}
        #dv-poster-overlay .dv-ov-bar i{display:block;height:100%;width:0;
          background:linear-gradient(90deg,#10b981,#059669);transition:width .3s}
        #dv-poster-overlay .dv-ov-ver{margin-top:12px;font-size:11px;color:#9ca3af}`;
      document.documentElement.appendChild(s);
      document.documentElement.appendChild(overlayEl);
    }
    overlayEl.querySelector('.dv-ov-text').textContent = text;
    if (typeof pct === 'number') overlayEl.querySelector('.dv-ov-bar i').style.width = pct + '%';
  }
  function hideOverlay() {
    if (overlayEl) { overlayEl.remove(); overlayEl = null; }
  }
  const isTopDoc = () => {
    try { return window.top === window.self; } catch (e) { return false; }
  };

  // ---------- 드래프트 복원 팝업 자동 취소 ----------
  async function dismissDraftPopup() {
    // "작성 중이던 글이 있습니다" 류 팝업 → '취소'(새 글로 시작) 클릭
    await sleep(300);
    const candidates = [...document.querySelectorAll('button, a, .se-popup-button, [class*="popup"] button')];
    for (const btn of candidates) {
      const t = (btn.textContent || '').trim();
      if (t === '취소' || t === '아니오' || t === '새로 작성' || t === '새글쓰기') {
        try { btn.click(); console.log(TAG, '드래프트 팝업 취소'); await sleep(300); return true; } catch (e) {}
      }
    }
    return false;
  }

  // ---------- 이미지: base64 → File ----------
  function base64ToFile(dataUrl, name) {
    const [head, body] = dataUrl.split(',');
    const mime = (head.match(/data:(.*?);/) || [])[1] || 'image/jpeg';
    const bin = atob(body);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new File([arr], name, { type: mime });
  }

  // ---------- 이미지 드롭 삽입 ----------
  async function dropImage(file) {
    const target =
      document.querySelector('.se-content .se-components-wrap') ||
      document.querySelector('.se-content') ||
      document.querySelector('.se-dnd-wrap') ||
      document.querySelector('.se-component.se-text');
    if (!target) throw new Error('드롭 대상 없음');

    const dt = new DataTransfer();
    dt.items.add(file);
    const r = target.getBoundingClientRect();
    const opts = {
      bubbles: true, cancelable: true, composed: true, dataTransfer: dt,
      clientX: r.left + r.width / 2, clientY: r.top + r.height - 8,
    };
    target.dispatchEvent(new DragEvent('dragenter', opts));
    target.dispatchEvent(new DragEvent('dragover', opts));
    target.dispatchEvent(new DragEvent('drop', opts));
  }

  async function insertImages(images) {
    if (!images || !images.length) return { inserted: 0 };
    let ok = 0;
    for (let i = 0; i < images.length; i++) {
      try {
        const file = base64ToFile(images[i], `image_${Date.now()}_${i}.jpg`);
        await dropImage(file);
        ok++;
        showOverlay(`🖼️ 이미지 삽입 중... (${ok}/${images.length})`, 60 + (i / images.length) * 20);
        await sleep(1800); // 네이버 업로드 처리 대기
      } catch (e) {
        console.warn(TAG, '이미지 삽입 실패', i, e.message);
      }
    }
    return { inserted: ok };
  }

  // ---------- React 제어 select 값 설정 ----------
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLSelectElement ? HTMLSelectElement.prototype
      : el instanceof HTMLInputElement ? HTMLInputElement.prototype
      : HTMLElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ---------- 공개설정 라디오 ----------
  function setOpenType(type) {
    const map = { public: '#open_public', neighbor: '#open_neighbor', both: '#open_both_neighbor', private: '#open_private' };
    const el = document.querySelector(map[type] || map.public);
    if (el && !el.checked) { el.click(); }
  }

  // ---------- 최종 동작: 임시저장 / 즉시발행 / 예약발행 ----------
  async function finalize(job) {
    const action = job.finalAction || 'draft';

    if (action === 'draft') {
      // 임시저장
      showOverlay('💾 임시저장 중...', 90);
      const saveBtn =
        document.querySelector('[data-click-area="tpb.save"]') ||
        document.querySelector('.save_btn__bzc5B') ||
        [...document.querySelectorAll('button')].find((b) => (b.textContent || '').trim() === '저장');
      if (!saveBtn) throw new Error('임시저장 버튼 없음');
      saveBtn.click();
      await sleep(1500);
      // 저장 확인 팝업이 뜨면 확인 클릭
      await clickConfirmIfAny();
      return { done: true, action: 'draft' };
    }

    // 발행 계열: 발행 버튼 클릭 → 레이어 열기
    showOverlay('📤 발행 설정 여는 중...', 88);
    const publishOpenBtn =
      document.querySelector('[data-click-area="tpb.publish"]') ||
      document.querySelector('.publish_btn__m9KHH') ||
      [...document.querySelectorAll('button')].find((b) => (b.textContent || '').trim() === '발행');
    if (!publishOpenBtn) throw new Error('발행 버튼 없음');
    publishOpenBtn.click();

    // 레이어 대기
    const finalBtn = await waitFor('[data-testid="seOnePublishBtn"], [data-click-area="tpb*i.publish"]', { timeout: 8000 });
    if (!finalBtn) throw new Error('발행 레이어 열림 실패');
    await sleep(400);

    // 공개설정 반영
    if (job.options?.openType) setOpenType(job.options.openType);
    // 검색허용 반영(옵션)
    if (job.options && job.options.search === false) {
      const s = document.querySelector('#publish-option-search');
      if (s && s.checked) s.click();
    }

    if (action === 'schedule' && job.schedule?.datetime) {
      showOverlay('⏰ 예약 시간 설정 중...', 92);
      // 예약 라디오 켜기
      const pre = document.querySelector('#radio_time2, [data-testid="preTimeRadioBtn"]');
      if (pre && !pre.checked) pre.click();
      await sleep(400);

      const dt = new Date(job.schedule.datetime);
      const hh = String(dt.getHours()).padStart(2, '0');
      // 분은 10분 단위만 허용 → 내림
      const mm = String(Math.floor(dt.getMinutes() / 10) * 10).padStart(2, '0');

      const hourSel = document.querySelector('select.hour_option__J_heO, .hour__ckNMb select');
      const minSel = document.querySelector('select.minute_option__Vb3xB, .minute__KXXvZ select');
      if (hourSel) setNativeValue(hourSel, hh);
      if (minSel) setNativeValue(minSel, mm);

      // 날짜: 당일이 아니면 캘린더 조작이 필요(현재 당일 기준). 값은 best-effort로 설정.
      const dateInput = document.querySelector('input.input_date__QmA0s, .date__Lkn7S input');
      if (dateInput) {
        const y = dt.getFullYear();
        const mo = String(dt.getMonth() + 1).padStart(2, '0');
        const d = String(dt.getDate()).padStart(2, '0');
        try { setNativeValue(dateInput, `${y}. ${mo}. ${d}`); } catch (e) {}
      }
      await sleep(300);
    }

    // 최종 발행 클릭
    showOverlay(action === 'schedule' ? '⏰ 예약발행 확정...' : '📤 발행 중...', 96);
    finalBtn.click();
    await sleep(2000);
    await clickConfirmIfAny();
    return { done: true, action };
  }

  async function clickConfirmIfAny() {
    await sleep(400);
    const btn = [...document.querySelectorAll('button, a')].find((b) => {
      const t = (b.textContent || '').trim();
      return t === '확인' || t === '발행' || t === '예';
    });
    if (btn) { try { btn.click(); await sleep(500); } catch (e) {} }
  }

  // ============================================================
  // 메시지 라우터 (background ↔ 이 프레임)
  // ============================================================
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.action) return;

    // 에디터 프레임만 처리하는 명령들
    const editorOnly = ['GET_POSITIONS', 'DISMISS_POPUP', 'INSERT_IMAGES', 'FINALIZE', 'PROGRESS'];
    if (editorOnly.includes(msg.action) && !isEditorFrame()) return; // 다른 프레임은 무시

    (async () => {
      try {
        switch (msg.action) {
          case 'PING':
            sendResponse({ ok: true, version: '15.0.0', editor: isEditorFrame() });
            break;
          case 'PROGRESS':
            showOverlay(msg.text, msg.pct);
            sendResponse({ ok: true });
            break;
          case 'DISMISS_POPUP':
            await dismissDraftPopup();
            sendResponse({ ok: true });
            break;
          case 'GET_POSITIONS': {
            const titlePara = document.querySelector('.se-documentTitle .se-text-paragraph');
            const bodyPara = document.querySelector('.se-component.se-text .se-text-paragraph');
            sendResponse({
              ok: !!(titlePara && bodyPara),
              title: titlePara ? absoluteRect(titlePara) : null,
              body: bodyPara ? absoluteRect(bodyPara) : null,
            });
            break;
          }
          case 'INSERT_IMAGES': {
            const res = await insertImages(msg.images);
            sendResponse({ ok: true, ...res });
            break;
          }
          case 'FINALIZE': {
            const res = await finalize(msg.job);
            hideOverlay();
            sendResponse({ ok: true, ...res });
            break;
          }
          case 'HIDE_OVERLAY':
            hideOverlay();
            sendResponse({ ok: true });
            break;
          default:
            break;
        }
      } catch (e) {
        console.error(TAG, msg.action, '실패', e);
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true; // async
  });

  // ============================================================
  // 진입: 에디터 준비되면 background에 알림
  // ============================================================
  async function boot() {
    if (!/GoBlogWrite|PostWriteForm|editor/i.test(location.href) && !isEditorFrame()) {
      // 글쓰기 관련 페이지가 아니면 대기만
    }
    // 편집 대상 프레임에서만 부팅
    const title = await waitFor('.se-documentTitle .se-text-paragraph', { timeout: 25000 });
    if (!title) { console.log(TAG, '에디터 미발견(이 프레임 아님)'); return; }

    console.log(TAG, '에디터 준비됨, background에 EDITOR_READY 전송');
    showOverlay('✍️ 자동 작성을 시작합니다...', 5);
    try {
      const resp = await chrome.runtime.sendMessage({ action: 'EDITOR_READY' });
      if (!resp || !resp.hasJob) hideOverlay();
    } catch (e) {
      console.log(TAG, 'EDITOR_READY 전송 실패', e.message);
      hideOverlay();
    }
  }

  if (document.readyState === 'complete') boot();
  else window.addEventListener('load', boot);
})();
